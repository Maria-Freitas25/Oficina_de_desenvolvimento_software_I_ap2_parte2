[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://share.streamlit.io/streamlit/example-app-bug-report/main)

# 🐞 Bug Report app

An app to show how Streamlit can easily collect and write data from/to a database (here a simple Google Sheet)

<img width="583" alt="screenshot" src="https://user-images.githubusercontent.com/7164864/141757795-45576b0b-7322-4ef1-b2cc-32a8f108eb7f.png">
